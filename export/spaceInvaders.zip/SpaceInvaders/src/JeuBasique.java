import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.BasicGame;
import org.newdawn.slick.Color;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Input;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.Image;

public class JeuBasique extends BasicGame {
	/**
	 * Exemple d'un objet déplacé par un "joueur"
	 *
	 * @author Antoine Rozenknop
	 */
	/** Position du mobile */
	private float mobile_X = 320;
	private float mobile_Y = 240;

	/** Position du laser */
	private int NOMBRE_LASER=50;
	private int nb_laser_actif=0;
	private float[] laser_X;
	private float[] laser_Y;

	/** Orientation du mobile */
	private float mobile_angle = 0;

	/** Vitesse du mobile */
	private float mobile_VX = 0;
	private float mobile_VY = 0;

	/** Position du papier peint */
	private float ciel_X = 0;
	private float ciel_flipped_X = 0;

	/** Images */
	private Image mobile_image;
	private Image[] mobile_laser;
	private Image ciel_image;
	private Image ciel_image_flipped;

	/**
	 * Construction de l'objet JeuBasique
	 */
	public JeuBasique() {
		// appel au constructeur de la classe parente : BasicGame
		super("Jeu basique");
	}

	/**
	 * Initialisation du jeu
	 */
	public void init(GameContainer container) throws SlickException {
		// On demande au conteneur d'essayer d'afficher 100 images par secondes
		container.setTargetFrameRate(100);
		// On demande au conteneur d'afficher le nombre d'images par secondes
		// réel
		container.setShowFPS(true);
		// Affichage en plein écran
		container.setFullscreen(true);

		// On charge les images depuis le disque
		mobile_image = new Image("ressources/plane.png");

		mobile_laser = new Image[NOMBRE_LASER];
		for(int i=0;i<mobile_laser.length;i++)
				mobile_laser[i]= new Image("ressources/laser.png");
		laser_X=new float[NOMBRE_LASER];
		laser_Y=new float[NOMBRE_LASER];
		for(int i=0;i<mobile_laser.length;i++){
			laser_X[i]=1500;
			laser_Y[i]=1500;
		}

		ciel_image = new Image("ressources/land.png");
		// On redimensionne le papier peint à la taille de la fenêtre
		ciel_image = ciel_image.getScaledCopy(container.getWidth(),
				container.getHeight());
		// Et on en crée une copie retournée verticalement
		ciel_image_flipped = ciel_image.getFlippedCopy(true, false);
		ciel_flipped_X = ciel_image.getWidth();
	}

	/**
	 * Affichage du jeu La méthode render est appelée régulièrement par le
	 * framework Slick2 Elle reçoit automatiquement deux paramètres : le
	 * "container" (qui représente la fenêtre dans laquelle le jeu apparaît), et
	 * un "contexte graphique" qui représente la surface à l'intérieur de cette
	 * fenêtre. C'est ce contexte graphique que l'on utilise pour tracer les
	 * objets.
	 */
	public void render(GameContainer container, Graphics g) {
		// affichage du papier peint
		g.drawImage(ciel_image, ciel_X, 0);
		g.drawImage(ciel_image_flipped, ciel_flipped_X, 0);

		// affichage du mobile
		g.drawImage(mobile_image, mobile_X, mobile_Y);

		// affichage du laser
		for(int i=0;i<mobile_laser.length;i++)
			g.drawImage(mobile_laser[i], laser_X[i], laser_Y[i]);

	}

	/**
	 * Mise-à-jour des éléments du jeu La méthode update est appelée
	 * régulièrement par le framework Slick (avant chaque appel à la méthode
	 * render). Elle reçoit automatiquement deux paramètres : le "container"
	 * (qui représente la fenêtre dans laquelle le jeu apparaît), et un "delta".
	 * Ce "delta" représente le nombre de millisecondes qui se sont écoulées
	 * depuis la dernière mise-à-jour.
	 */
	public void update(GameContainer container, int delta) {

		// récupération d'un objet "input" depuis le "containeur"
		// Cet objet "sait" quelles sont les touches du clavier enfoncées
		Input input = container.getInput();

		// calcul du delta en secondes
		float delta_sec = delta * 0.001f;

		// déplacement du fond d'écran, à une vitesse de 130 pixels par seconde
		// vers la gauche
		ciel_X = ciel_X - 130 * delta_sec;
		if (ciel_X < -ciel_image.getWidth())
			ciel_X = ciel_flipped_X + ciel_image_flipped.getWidth();
		ciel_flipped_X = ciel_flipped_X - 130 * delta_sec;
		if (ciel_flipped_X < -ciel_image_flipped.getWidth())
			ciel_flipped_X = ciel_X + ciel_image.getWidth();

		// déplacement du mobile en fonction de la vitesse calculée
		// et du temps delta_sec
		mobile_X = mobile_X + mobile_VX * delta_sec;
		mobile_Y = mobile_Y + mobile_VY * delta_sec;

		for(int i=0;i<mobile_laser.length;i++)
		    laser_X[i] = laser_X[i] + 25;

		// modification de l'orientation du mobile par appui simultané
		// du déplacement latéral et de l'accélération
		if (input.isKeyDown(Input.KEY_Z) && input.isKeyDown(Input.KEY_Q)) {
			mobile_image.rotate(100 * delta_sec);
			mobile_angle=mobile_image.getRotation();
			return;
		}
		if (input.isKeyDown(Input.KEY_Z) && input.isKeyDown(Input.KEY_D)) {
			mobile_image.rotate(-100 * delta_sec);
			mobile_angle=mobile_image.getRotation();
			return;
		}

		// accélération du mobile, à 100 pixels/s²
		// dans une direction dépendant des touches enfoncées
		if (input.isKeyDown(Input.KEY_Z)) {
			mobile_VY = mobile_VY - 1000 * delta_sec;
		}
		if (input.isKeyDown(Input.KEY_S)) {
			mobile_VY = mobile_VY + 1000 * delta_sec;
		}
		if (input.isKeyDown(Input.KEY_D)) {
			mobile_VX = mobile_VX + 1000 * delta_sec;
		}
		if (input.isKeyDown(Input.KEY_Q)) {
			mobile_VX = mobile_VX - 1000 * delta_sec;
		}
		if (input.isKeyDown(Input.KEY_G)) {
			double angle=(double)mobile_angle;
			laser_X[nb_laser_actif%NOMBRE_LASER] = (float)(mobile_X+650 *Math.cos(angle));
			laser_Y[nb_laser_actif%NOMBRE_LASER] = (float)(mobile_Y+40 *Math.sin(angle));
			nb_laser_actif++;
		}

	}

	/**
	 * Une autre façon de repérer lorsqu'une touche est enfoncée : la méthode
	 * keyPressed appelée automatiquement par Slick à chaque touche enfoncée
	 */
	public void keyPressed(int key, char c) {
		if (key == Input.KEY_ESCAPE) {
			System.exit(0);
		}
	}

	/**
	 * keyReleased est appelée automatiquement par Slick à chaque touche
	 * relâchée
	 */
	public void keyReleased(int key, char c) {
		if (key == Input.KEY_F1) {
			// recentrage du mobile
			mobile_X = 320;
			mobile_Y = 240;
		}
		/*
		if (key == Input.KEY_G) {
			double angle=(double)mobile_angle;
			laser_X[nb_laser_actif%NOMBRE_LASER] = (float)(mobile_X+650 *Math.cos(angle));
			laser_Y[nb_laser_actif%NOMBRE_LASER] = (float)(mobile_Y+40 *Math.cos(angle));
			nb_laser_actif++;
		}
		*/
	}

	/**
	 * Point d'entrée du programme
	 *
	 * @param argv
	 *            Les arguments passés en ligne de commande
	 */
	public static void main(String[] argv) {
		try {
			// Création d'un JeuBasique
			// Puis création d'une fenêtre de jeu (AppGameContainer) à laquelle
			// on associe le JeuBasique
			AppGameContainer container = new AppGameContainer(new JeuBasique());
			// Taille de la fenêtre
			container.setDisplayMode(container.getScreenWidth(),
					container.getScreenHeight(), false);
			// Démarrage du jeu contenu dans la fenêtre
			container.start();

		} // gestion des erreurs
		catch (SlickException e) {
			e.printStackTrace();
		}
	}
}