package SpaceInvader;

import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;

/**
 * @author Gr�goire Le Cun
 */
public class Figure {
	private float posX;
	private float posY;
	private Image imgFigure;

	public Figure(float posX, float posY, Image imgFigure) {
		super();
		this.posX = posX;
		this.posY = posY;
		this.imgFigure = imgFigure;
	}

	public float getPosX() {
		return posX;
	}
	public void setPosX(float posX) {
		this.posX = posX;
	}
	public float getPosY() {
		return posY;
	}
	public void setPosY(float posY) {
		this.posY = posY;
	}
	public Image getImgFigure() {
		return imgFigure;
	}
	public void setImgFigure(Image imgFigure) {
		this.imgFigure = imgFigure;
	}
	public void render(Graphics g){
		g.drawImage(getImgFigure(),getPosX(),getPosY());
	}
	public void update(){};
	public void destruct(GameContainer container){
		this.setPosX(container.getWidth()+20);
		this.setPosY(0);

	}

}
