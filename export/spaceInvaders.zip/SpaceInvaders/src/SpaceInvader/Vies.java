package SpaceInvader;

import org.newdawn.slick.Graphics;

/**
 * @author Gr�goire Le Cun
 */
public class Vies {

	private int nbVies;

	public Vies(int nbVies) {
		this.nbVies = nbVies;
	}

	public int getNbVies() {
		return nbVies;
	}

	public void setNbVies(int nbVies) {
		this.nbVies = nbVies;
	}

	public void render(Graphics g,int X){
		g.drawString("Vies : "+getNbVies(),X,10);
	}

}
