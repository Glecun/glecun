package SpaceInvader;

import org.newdawn.slick.Graphics;

/**
 * @author Gr�goire Le Cun
 */
public class Score{

	private int score;

	public Score() {
		super();
		this.score = 0;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

	public void ennemyDown(){
		score+=10;
	}

	public void render(Graphics g){
		g.drawString("Score : "+getScore(),100,30);
	}


}
