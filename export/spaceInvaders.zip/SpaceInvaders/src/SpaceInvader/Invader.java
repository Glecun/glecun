package SpaceInvader;

import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;

/**
 * @author Gr�goire Le Cun
 */
public class Invader extends FigureWithLaser{

	private int vitesseRandom;
	private float timeLastAvance;
	private Image image1;
	private Image image2;

	public Invader(Image imgFigure,Image imgFigure2, float posX, float posY, Laser invLaser, int vitesseTir ) {
		super(posX, posY, imgFigure,invLaser);
		this.image1 = imgFigure;
		this.image2 = imgFigure2;
		//On peux r�gler la vitesse des tirs selon le mode de difficult�
		if (vitesseTir==1) vitesseRandom=9950;
		if (vitesseTir==2) vitesseRandom=9900;
		if (vitesseTir==3) vitesseRandom=9850;
	}

	public void render(Graphics g){
		if (!isMort()){
			g.drawImage(getImgFigure(),getPosX(),getPosY());
		}
		getLaser().render(g);
	}

	public void update(int move, GameContainer container,int delta){
		if(!isMort()){
			//Gestion du d�placement et de l'alternance des images
			float delta_sec = delta * 0.001f;
			this.timeLastAvance = this.timeLastAvance + delta_sec;
			if(timeLastAvance>0.8){
				this.timeLastAvance = 0;
				setPosX(getPosX()+move);
				if(this.getImgFigure().equals(image1))this.setImgFigure(image2);
				else this.setImgFigure(image1);
			}
			if( (Math.random() * ( 10000 - 0 ))>vitesseRandom) tirer(container);
		}
		getLaser().update(10);
	}

	public void tirer(GameContainer container){
		if (!getLaser().isActif(container)){
			getLaser().setPosX(getPosX()+60);
			getLaser().setPosY(getPosY()+50);
		}
	}
}
