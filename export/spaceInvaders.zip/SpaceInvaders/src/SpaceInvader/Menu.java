package SpaceInvader;

import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.SlickException;

/**
 * @author Gr�goire Le Cun
 */
public class Menu {
	private Background menu;
	private boolean menuActif;

	public Menu(GameContainer container) throws SlickException {
		this.menu =  new Background(container,"ressources/menu.png");
		this.menuActif = true;
	}

	public Background getMenu() {
		return menu;
	}

	public void setMenu(Background menu) {
		this.menu = menu;
	}

	public boolean isMenuActif() {
		return menuActif;
	}

	public void setMenuActif(boolean menuActif) {
		this.menuActif = menuActif;
	}

	public void render(Graphics g){
		menu.render(g);
		g.drawString("Tape 1 : Pour mode Arcade",20,700);
		g.drawString("Tape 2 : Pour mode Hardcore",20,750);
		g.drawString("Tape 3 : Pour mode Arcade 2 joueurs",20,800);
		g.drawString("Tape 4 : Pour mode Hardcore 2 joueurs",20,850);
		g.drawString("Tape 5 : Pour fuir comme un pleutre",20,900);
	}

}
