package SpaceInvader;

import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;

/**
 * @author Gr�goire Le Cun
 */
public class Boss extends FigureWithLaser {

	private float timeLastAvance;
	private float timeLastTir;
	private Laser tirPhase1;
	private Laser tirPhase2;
	//0 move left, 1 move right
	private int status;
	private Vies vie;
	private boolean revie;

	public Boss(float posX, float posY, Image imgFigure,Laser tirPhase1,Laser tirPhase2, Laser laser, int nbVies) {
		super(posX, posY, imgFigure, laser);
		this.tirPhase1 = tirPhase1;
		this.tirPhase2 = tirPhase2;
		status=0;
		vie = new Vies(nbVies);
		revie=false;
		getTirPhase1().getImgFigure().rotate(-90);
		getTirPhase2().getImgFigure().rotate(-90);
		getLaser().getImgFigure().rotate(-90);
		getLaser().setImgFigure(getLaser().getImgFigure().getScaledCopy(getLaser().getImgFigure().getWidth(),770));
	}

	public void update(int move, GameContainer container,int delta){
		if(!isMort()){
			//Gestion du sens de d�placement en fontion de la position
			if((getPosX()+getImgFigure().getWidth())>container.getWidth()){
				status=0;
			}
			if(getPosX()<0){
				status=1;
			}
			if (status==0)move=move*-1;
			
			//Pour le faire avancer par acoup 
			float delta_sec = delta * 0.001f;
			this.timeLastAvance = this.timeLastAvance + delta_sec;
			if(timeLastAvance>0.8){
				this.timeLastAvance = 0;
				setPosX(getPosX()+move);
				if (getLaser().isActif(container)) tirer(container);
			}
			
			//Gestion des diff�rentes phses de tirs
			this.timeLastTir = this.timeLastTir + delta_sec;
			if( (Math.random() * ( 10000 - 0 ))>9950  && timeLastTir>4){
				this.timeLastTir = 0;
				activePhase(container, 0);
				tirer(container);
			}
			if(timeLastTir>2) {
				getLaser().destruct(container);
			}
			if(!getLaser().isActif(container) && timeLastTir>2 && timeLastTir<3)activePhase(container, 1);
			if(!getLaser().isActif(container) && timeLastTir>3)activePhase(container, 2);
			
			//Gestion de la mort
			if (vie.getNbVies()<=0) LAMORT(container);
		}
	}

	public void tirer(GameContainer container){
		getLaser().setPosX(getPosX()+13);
		getLaser().setPosY(getPosY()+225);
	}
	
	/**
	 * Activation d'une phase de tir (1 ou 2) 
	 * @param container
	 * @param phase
	 */
	public void activePhase(GameContainer container, int phase){
		getTirPhase1().destruct(container);
		getTirPhase2().destruct(container);
		if (phase == 1){
			getTirPhase1().setPosX(getPosX()+13);
			getTirPhase1().setPosY(getPosY()+220);
		}
		if (phase == 2){
			getTirPhase2().setPosX(getPosX()+13);
			getTirPhase2().setPosY(getPosY()+220);
		}
	}

	public void hit(){
		vie.setNbVies(vie.getNbVies()-1);
	}

	public void render(Graphics g){
		getLaser().render(g);
		getTirPhase1().render(g);
		getTirPhase2().render(g);
		vie.render(g, 300);
		if (!isMort()){
			g.drawImage(getImgFigure(),getPosX(),getPosY());
		}
	}

	public void revivre(GameContainer container){
		setPosX((container.getWidth()/2) - 200);
		setPosY(5);
	}

	public boolean isRevie() {
		return revie;
	}

	public void setRevie(boolean revie) {
		this.revie = revie;
	}

	public Laser getTirPhase1() {
		return tirPhase1;
	}

	public void setTirPhase1(Laser tirPhase1) {
		this.tirPhase1 = tirPhase1;
	}

	public Laser getTirPhase2() {
		return tirPhase2;
	}

	public void setTirPhase2(Laser tirPhase2) {
		this.tirPhase2 = tirPhase2;
	}


}
