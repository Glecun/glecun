package SpaceInvader;

import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.SlickException;

/**
 * @author Gr�goire Le Cun
 */
public class Vaisseau extends FigureWithLaser{

	private Vies vies ;
	private Image vais_image_gauche;
	private Image vais_image_droite;
	private Image vais_image;

	public Vaisseau(Image vais_image,Image vais_image_gauche,Image vais_image_droite, float posX, float posY,GameContainer container) throws SlickException {
		super(posX,posY,vais_image,new Laser(container.getWidth()+30,0,new Image("ressources/laser.png")));
		this.vais_image=vais_image;
		this.vais_image_gauche=vais_image_gauche;
		this.vais_image_droite=vais_image_droite;
		vies = new Vies(3);
		getImgFigure().rotate(180);
		getVais_image_droite().rotate(180);
		getVais_image_gauche().rotate(180);
	}

	public void render(Graphics g,int posXVie){
			g.drawImage(getImgFigure(),getPosX(),getPosY());
			getLaser().render(g);
			vies.render(g,posXVie);
	}

	public void update(GameContainer container){
		getLaser().update(-17);
		if(getPosX()>0){
			setPosX(getPosX());
			setPosY(getPosY());
		}
		if(getPosX()+super.getImgFigure().getWidth()>=container.getWidth()){
			setPosX(container.getWidth()-super.getImgFigure().getWidth());
		}
		if(getPosX()<=0){
			setPosX(1);
		}
	}

	public void tirer(GameContainer container){
		if (!getLaser().isActif(container)){
			getLaser().setPosX(getPosX()+(getImgFigure().getWidth()/2)-6);
			getLaser().setPosY(getPosY()+5);
		}
	}

	public void LAMORT(GameContainer container){
		this.mort = true;
		this.setPosX(0);
		this.getImgFigure().rotate(90);
	}

	public void hit(){
		vies.setNbVies(vies.getNbVies()-1);
	}

	public Image getVais_image_gauche() {
		return vais_image_gauche;
	}

	public void setVais_image_gauche(Image vais_image_gauche) {
		this.vais_image_gauche = vais_image_gauche;
	}

	public Image getVais_image_droite() {
		return vais_image_droite;
	}

	public void setVais_image_droite(Image vais_image_droite) {
		this.vais_image_droite = vais_image_droite;
	}

	public Image getVais_image() {
		return vais_image;
	}

	public void setVais_image(Image vais_image) {
		this.vais_image = vais_image;
	}

	public Vies getVies() {
		return vies;
	}

	public void setVies(Vies vies) {
		this.vies = vies;
	}


}
