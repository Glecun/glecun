package SpaceInvader;

import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.SlickException;

/**
 * @author Gr�goire Le Cun
 */
public class Background extends Figure{

	public Background(GameContainer container, String cheminImage) throws SlickException {
		super(0, 0, new Image(cheminImage));
		// On redimensionne le papier peint �la taille de la fen�tre
		super.setImgFigure(super.getImgFigure().getScaledCopy(container.getWidth(),
				container.getHeight()));

	}
	/**
	 * render the Background with the score
	 * @param g
	 * @param score
	 * @param container
	 */
	public void render(Graphics g, Score score, GameContainer container ){
		super.render(g);
		g.drawString("Score : "+score.getScore(),(container.getWidth()/2)-20,10);
	}

}
