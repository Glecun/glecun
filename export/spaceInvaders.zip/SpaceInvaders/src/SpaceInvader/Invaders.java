package SpaceInvader;

import java.util.ArrayList;

import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.SlickException;

/**
 * @author Gr�goire Le Cun
 */
public class Invaders {

	private ArrayList<Invader> invs;
	//0 move left, 1 move right
	private int status;
	
	/**
	 * Instancie tout les invaders en fonction de la fenetre et du nombre d'invader souhait�.
	 * Les invader sont en ligne de 8.
	 * 
	 * @param nb
	 * @param container
	 * @param vitesseTir
	 * @throws SlickException
	 */
	public Invaders(int nb,GameContainer container,int vitesseTir) throws SlickException {
		int y=0;
		int x=0;
		status=1;
		invs = new ArrayList<Invader>();
		for (int i=0;i<nb;i++){
			if ((i%8)==0){
				y++;
				x=0;
			}
			invs.add(new Invader(new Image("ressources/invader.png"),
								 new Image("ressources/invader2.png"),
								(float)(140+(x*125)),
								(float)(0+(100*y)),
								 new Laser(container.getWidth(),0, new Image("ressources/laser.png")),
								 vitesseTir
								));
			x++;
		}
	}

	public void render(Graphics g){
		for(Invader inv : invs){
			inv.render(g);
		}
	}

	public void update(GameContainer container,int delta){

		//On prend le dernier Invader de la premiere ligne pour les deplacements
		Invader lastInvader= invs.get(7);
		for(int i=7;i>0;i--){
			if (invs.get(i).isMort()){
				lastInvader=invs.get(i-1);
			}else{
				break;
			}
		}
		//On prend le premier Invader de la premiere ligne pour les deplacements
		Invader firstInvader= invs.get(0);
		for(int i=0;i<8;i++){
			if (invs.get(i).isMort()){
				firstInvader=invs.get(i+1);
			}else{
				break;
			}
		}

		if((lastInvader.getPosX()+lastInvader.getImgFigure().getWidth())>container.getWidth()){
			status=0;
			for(Invader inv : invs){
				inv.setPosY(inv.getPosY()+15);
				inv.setPosX(inv.getPosX()-13);
			}
		}
		if(firstInvader.getPosX()<0){
			status=1;
			for(Invader inv : invs){
				inv.setPosY(inv.getPosY()+15);
				inv.setPosX(inv.getPosX()+13);
			}
		}
		for(Invader inv : invs){
			if (status==1)inv.update(13,container,delta);
			if (status==0)inv.update(-13,container,delta);
		}

	}

	public ArrayList<Invader> getInvs() {
		return invs;
	}

	public void setInvs(ArrayList<Invader> invs) {
		this.invs = invs;
	}

	public boolean isTousMort(){
		for (Invader inv : invs){
			if(inv.isMort()==false)
				return false;
		}
		return true;
	}

}


