package SpaceInvader;

import java.util.ArrayList;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.SlickException;

/**
 * Un Mur est un ensemble de carr�s destructible
 *
 * @author Gr�goire Le Cun
 *
 */
public class Mur {

	private ArrayList<Figure> carres;

	public Mur(int posx, int posy) throws SlickException {
		int y=0;
		int x=0;
		carres = new ArrayList<Figure>();
		Image tmpImg = new Image("ressources/carre2.png");
		for (int i=0;i<16;i++){
			if ((i%8)==0){
				y++;
				x=0;
			}
			carres.add(new Figure((float)posx+tmpImg.getWidth()*x,
								  (float)posy+tmpImg.getHeight()*y,
								  new Image("ressources/carre2.png")
								 ));
			x++;
		}
	}

	public void render(Graphics g){
		for(Figure carre : carres){
			carre.render(g);
		}
	}

	public ArrayList<Figure> getCarres() {
		return carres;
	}

	public void setCarres(ArrayList<Figure> carres) {
		this.carres = carres;
	}

}
