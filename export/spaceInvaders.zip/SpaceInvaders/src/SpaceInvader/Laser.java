package SpaceInvader;

import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;

/**
 * @author Gr�goire Le Cun
 */
public class Laser extends Figure{

	public Laser(float posX, float posY, Image imgFigure) {
		super(posX, posY, imgFigure);
		super.getImgFigure().rotate(90);
	}

	public void update(int move){
		setPosY(getPosY() + move);
	}

	public boolean isActif(GameContainer container){
		return getPosY()>0 && getPosY()<container.getHeight() && getPosX()>-20 && getPosX()<container.getWidth()-10;
	}
}
