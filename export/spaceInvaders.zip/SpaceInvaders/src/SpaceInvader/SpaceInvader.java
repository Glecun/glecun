package SpaceInvader;
import java.util.ArrayList;

import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.BasicGame;
import org.newdawn.slick.Color;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Input;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.Image;

/**
 * @author Gr�goire Le Cun
 */
public class SpaceInvader extends BasicGame {

	/** Vaisseau Joueur */
	Vaisseau vais;
	Vaisseau vais2;
	private float timeLastBossTouche;
	private float timeLastBossTouche2;

	/** Background */
	Background ciel;
	Background fin;
	Background victory;

	/** Ensemble d'Invaders*/
	int NB_ALIEN=16;
	int NB_VIE_BOSS=15;
	int VITESSE_TIR=1;
	Invaders invs;

	/**Boss**/
	Boss boss;

	/** Ensemble de Murs*/
	ArrayList<Mur> murs;

	/** Container**/
	GameContainer container;

	/** Score**/
	Score score;

	/** Menu**/
	Menu menu;
	int modeChoisi = 0;


	public SpaceInvader() {
		super("Space Invader");
	}

	/**
	 * Initialisation du jeu
	 */
	public void init(GameContainer container) throws SlickException {
		this.container = container;
		// On demande au conteneur d'essayer d'afficher 100 images par secondes
		container.setTargetFrameRate(100);
		// On demande au conteneur d'afficher le nombre d'images par secondes
		container.setShowFPS(true);

		//on instancie les 3 �cran(en jeu, vicoire, d�faite)
		ciel = new Background(container,"ressources/land.png");
		fin= new Background(container,"ressources/fin.png");
		victory= new Background(container,"ressources/victory.png");

		menu = new Menu(container);

		if (modeChoisi==3){ //Si  le mode 2 joueurs est choisi, on cr�e 2 vaisseaux
			vais= new Vaisseau(new Image("ressources/plane1.png"),new Image("ressources/plane1g.png"),new Image("ressources/plane1d.png"),(container.getWidth()/2)-40,container.getHeight()-120,container);
			vais2 = new Vaisseau(new Image("ressources/plane2.png"),new Image("ressources/plane2g.png"),new Image("ressources/plane2d.png"),(container.getWidth()/2)+ 245,container.getHeight()-120,container);
			timeLastBossTouche2=0;
		} else {
			vais= new Vaisseau(new Image("ressources/plane3.png"),new Image("ressources/plane3g.png"),new Image("ressources/plane3d.png"),(container.getWidth()/2)-60,container.getHeight()-120,container);
		}
		timeLastBossTouche=0;
		
		invs= new Invaders(NB_ALIEN,container,VITESSE_TIR);

		boss= new Boss(container.getWidth(), 0, new Image("ressources/boss.png"),new Laser(container.getWidth(),0, new Image("ressources/laserBossPhase1.png")),new Laser(container.getWidth(),0, new Image("ressources/laserBossPhase2.png")), new Laser(container.getWidth(),0, new Image("ressources/laserBoss.png")),NB_VIE_BOSS);

		score = new Score();

		murs = new ArrayList<Mur>();
		for (int i=0;i<3;i++)
			murs.add(new Mur(300+(i*280),700));
	}

	/**
	 * Affichage du jeu La méthode render est appelée régulièrement par le
	 * framework Slick2 Elle reçoit automatiquement deux paramètres : le
	 * "container" (qui représente la fenêtre dans laquelle le jeu apparaît), et
	 * un "contexte graphique" qui représente la surface à l'intérieur de cette
	 * fenêtre. C'est ce contexte graphique que l'on utilise pour tracer les
	 * objets.
	 * @throws SlickException
	 */
	public void render(GameContainer container, Graphics g) throws SlickException {
		if (menu.isMenuActif()){
			menu.render(g);
		}
		else if (vais.isMort()){ //Si le joueur 1 est mort, ecran de d�faite
			fin.render(g,score,container);
			vais.render(g,100);
			if(modeChoisi==3)	vais2.render(g,200);
		}
		else if ( boss.isMort() ){ // si le boss est mort, ecran de victoire
			victory.render(g,score,container);
			vais.render(g,100);
			if(modeChoisi==3)	vais2.render(g,200);
		}
		else if (invs.isTousMort()){ // si tout les invaders sont morts, on envoie le boss
			ciel.render(g);
			vais.render(g,100);
			if(modeChoisi==3)	vais2.render(g,200);
			boss.render(g);
			for (Mur m : murs)
				m.render(g);
			score.render(g);
		}
		else { //sinon on est en jeu.
			ciel.render(g);
			invs.render(g);
			vais.render(g,100);
			if(modeChoisi==3)	vais2.render(g,200);
			for (Mur m : murs)
				m.render(g);
			score.render(g);
		}

	}

	/**
	 * Mise-à-jour des éléments du jeu La méthode update est appelée
	 * régulièrement par le framework Slick (avant chaque appel à la méthode
	 * render). Elle reçoit automatiquement deux paramètres : le "container"
	 * (qui représente la fenêtre dans laquelle le jeu apparaît), et un "delta".
	 * Ce "delta" représente le nombre de millisecondes qui se sont écoulées
	 * depuis la dernière mise-à-jour.
	 * @throws SlickException
	 */
	public void update(GameContainer container, int delta) throws SlickException {
		// récupération d'un objet "input" depuis le "containeur"
		// Cet objet "sait" quelles sont les touches du clavier enfoncées
		Input input = container.getInput();

		float delta_sec = delta * 0.001f;
		
		//Si le Menu est actif on peut choisir un mode avec les touches 1,2,3,4 ou 5
		if (menu.isMenuActif()){

			if (input.isKeyDown(Input.KEY_1)) {
				modeChoisi=1;
				NB_ALIEN=16;
				NB_VIE_BOSS=15;
				VITESSE_TIR=1;
			}
			if (input.isKeyDown(Input.KEY_2)) {
				modeChoisi=2;
				NB_ALIEN=40;
				NB_VIE_BOSS=30;
				VITESSE_TIR=3;
			}
			if (input.isKeyDown(Input.KEY_3)) {
				modeChoisi=3;
				NB_ALIEN=16;
				NB_VIE_BOSS=30;
				VITESSE_TIR=1;
			}
			if (input.isKeyDown(Input.KEY_4)) {
				modeChoisi=3;
				NB_ALIEN=40;
				NB_VIE_BOSS=50;
				VITESSE_TIR=3;
			}
			if (input.isKeyDown(Input.KEY_5)) {
				System.exit(0);
			}
			if( (input.isKeyDown(Input.KEY_1)) || (input.isKeyDown(Input.KEY_2)) || input.isKeyDown(Input.KEY_3) || input.isKeyDown(Input.KEY_4)){
				init(container);
				menu.setMenuActif(false);
			}


		}
		else if (!vais.isMort() && !boss.isMort()){ //si le vaisseau et le bos ne sot pas mort

			ciel.update();

			vais.update(container);
			
			/** Si les invaders ne sont pas mort, on update les invaders . Sinon, le boss */
			if(!invs.isTousMort()) 
				invs.update(container,delta );
			else	
				boss.update(40,container,delta);
			
			/** Si le boss n'a jamais revie, on le fait revivre */
			if(invs.isTousMort() && !boss.isRevie()){
				boss.setRevie(true);
				boss.revivre(container);
			}

			/** Si le vaiseau n'a plus de vie, il est mort */
			if (vais.getVies().getNbVies()<=0){
				vais.LAMORT(container);
			}
			
			/** Gestion du d�placement + changement d'image quand il bouge */
			vais.setImgFigure(vais.getVais_image());
			if (input.isKeyDown(Input.KEY_D)) {
				if(vais.getPosX()+vais.getImgFigure().getWidth()<container.getWidth())
					vais.setPosX(vais.getPosX() +9);
				vais.setImgFigure(vais.getVais_image_droite());
			}
			if (input.isKeyDown(Input.KEY_Q)) {
				if(vais.getPosX()>0)
					vais.setPosX(vais.getPosX()- 9);
				vais.setImgFigure(vais.getVais_image_gauche());
			}

			/** si il y a un deuxi�me joueurs */
			if(modeChoisi==3)	{
				vais2.update(container);
				if (vais2.getVies().getNbVies()<=0){
					vais2.LAMORT(container);
					vais2.destruct(container);
				}
				vais2.setImgFigure(vais2.getVais_image());
				if (input.isKeyDown(Input.KEY_L)) {
					if(vais2.getPosX()+vais2.getImgFigure().getWidth()<container.getWidth())
						vais2.setPosX(vais2.getPosX() +9);
					vais2.setImgFigure(vais2.getVais_image_droite());
				}
				if (input.isKeyDown(Input.KEY_J)) {
					if(vais2.getPosX()>0)
						vais2.setPosX(vais2.getPosX()- 9);
					vais2.setImgFigure(vais2.getVais_image_gauche());
				}
			}

			/** Partie Collision */
			ArrayList<FigureWithLaser> vaisArray = new ArrayList<FigureWithLaser>();
			vaisArray.add(vais);
			ArrayList<FigureWithLaser> vais2Array = new ArrayList<FigureWithLaser>();
			vais2Array.add(vais2);
    		ArrayList<FigureWithLaser> bossArray = new ArrayList<FigureWithLaser>();
			bossArray.add(boss);

			if (Collision.figureTouche(vais,invs.getInvs(),container,true )){
				vais.hit();
			}

			if (Collision.figureTouche(boss,vaisArray,container ,true)){
				boss.hit();
			}

			this.timeLastBossTouche = this.timeLastBossTouche + delta_sec;
			if (Collision.figureTouche(vais,bossArray,container,false) && timeLastBossTouche>1.5){
				this.timeLastBossTouche = 0;
				vais.hit();
			}

			for(int i =0;i<NB_ALIEN;i++){
				if(Collision.figureTouche(invs.getInvs().get(i),vaisArray,container,true)){
					invs.getInvs().get(i).LAMORT(container);
					score.ennemyDown();
				}
			}

			for(Mur mur : murs){
				for(Figure c : mur.getCarres()){
					if (Collision.figureTouche(c,invs.getInvs(),container ,true)){
						c.destruct(container);
					}
					if (Collision.figureTouche(c,vaisArray,container ,true)){
						c.destruct(container);
					}
					if (Collision.figureTouche(c,bossArray,container ,true)){
						c.destruct(container);
					}
				}
			}
			/** Collision Vaisseau 2 */
			if (modeChoisi==3){
				if (Collision.figureTouche(vais2,invs.getInvs(),container ,true)){
					vais2.hit();
				}
				if (Collision.figureTouche(boss,vais2Array,container ,true)){
					boss.hit();
				}

				this.timeLastBossTouche2 = this.timeLastBossTouche2 + delta_sec;
				if (Collision.figureTouche(vais2,bossArray,container,false) && timeLastBossTouche2>1.5){
					this.timeLastBossTouche2 = 0;
					vais2.hit();
				}

				for(int i =0;i<NB_ALIEN;i++){
					if(Collision.figureTouche(invs.getInvs().get(i),vais2Array,container,true)){
						invs.getInvs().get(i).LAMORT(container);
						score.ennemyDown();
					}
				}
				for(Mur mur : murs){
					for(Figure c : mur.getCarres()){
						if (Collision.figureTouche(c,vais2Array,container ,true)){
							c.destruct(container);
						}
					}
				}
			}
		}else{ /** Sinon c'est un ecran de fin */
			vais.setPosX(vais.getPosX()+4);
			if (input.isKeyDown(Input.KEY_ENTER) || input.isKeyDown(Input.KEY_ESCAPE)) {
				menu.setMenuActif(true);
			}
		}

	}

	/**
	 * Une autre façon de repérer lorsqu'une touche est enfoncée : la méthode
	 * keyPressed appelée automatiquement par Slick à chaque touche enfoncée
	 */
	public void keyPressed(int key, char c) {
		if (key == Input.KEY_ESCAPE) {
			System.exit(0);
		}
	}

	/**
	 * keyReleased est appelée automatiquement par Slick à chaque touche
	 * relâchée
	 */
	public void keyReleased(int key, char c) {

		if (key == Input.KEY_G) {
			vais.tirer(container);
		}

		if (key == Input.KEY_M) {
			vais2.tirer(container);
		}
	}

	/**
	 * Point d'entrée du programme
	 *
	 * @param argv
	 *            Les arguments passés en ligne de commande
	 */
	public static void main(String[] argv) {
		try {
			// Création d'un JeuBasique
			// Puis création d'une fenêtre de jeu (AppGameContainer) à laquelle
			// on associe le JeuBasique
			AppGameContainer container = new AppGameContainer(new SpaceInvader());
			// Taille de la fenêtre
			//container.setDisplayMode(container.getScreenWidth(),container.getScreenHeight(), false);
			container.setDisplayMode(1280,1024, true);
			container.setTargetFrameRate(30);
			container.setVSync(true);
			// Démarrage du jeu contenu dans la fenêtre
			container.start();

		} // gestion des erreurs
		catch (SlickException e) {
			e.printStackTrace();
		}
	}
}