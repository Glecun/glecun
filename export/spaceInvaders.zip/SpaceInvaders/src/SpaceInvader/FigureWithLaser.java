package SpaceInvader;

import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Image;

/**
 * Une FigureWithLaser est une figure qui poss�de son Laser et qui peut mourir
 * 
 * @author Gr�goire Le Cun
 *
 */
public class FigureWithLaser extends Figure {

	Laser laser;
	boolean mort;

	public FigureWithLaser(float posX, float posY, Image imgFigure,Laser laser) {
		super(posX, posY, imgFigure);
		this.laser = laser;
		this.mort= false;
	}

	public Laser getLaser() {
		return laser;
	}

	public void setLaser(Laser laser) {
		this.laser = laser;
	}

	public void tirer(GameContainer container){
		if (!getLaser().isActif(container)){
			getLaser().setPosX(getPosX());
			getLaser().setPosY(getPosY());
		}
	}

	public boolean isMort(){
		return this.mort;
	}

	public void LAMORT(GameContainer container){
		this.mort=true;
		this.setPosX(container.getWidth());
		this.setPosY(0);
	}
}
