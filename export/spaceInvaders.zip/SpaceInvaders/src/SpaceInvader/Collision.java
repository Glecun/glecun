package SpaceInvader;

import java.util.ArrayList;

import org.newdawn.slick.GameContainer;

/**
 * @author Gr�goire Le Cun
 */
public final class Collision {

	public Collision() {};
	/**
	 * La methode static final figureTouche renvoi True si le laser d'une des FigureWithLaser de l'ArrayList touche la Figure figureTouche
	 * 
	 * @param figureTouche
	 * @param figures
	 * @param container
	 * @param destructLaser
	 * @return
	 */
    public static final boolean	figureTouche( Figure figureTouche  , ArrayList<? extends FigureWithLaser > figures, GameContainer container,boolean destructLaser ){
		for( int i=0; i<figures.size(); i++ ){
			if(
					!figures.get(i).isMort() && figures.get(i).getLaser().isActif(container)
				&&
            	(
            		( figures.get(i).getLaser().getPosX() >= figureTouche.getPosX()  && figures.get(i).getLaser().getPosX() <= ( figureTouche.getPosX() + figureTouche.getImgFigure().getWidth() ) ) ||
            		( ( figures.get(i).getLaser().getPosX() + figures.get(i).getLaser().getImgFigure().getWidth()) >= figureTouche.getPosX()  && ( figures.get(i).getLaser().getPosX() + figures.get(i).getLaser().getImgFigure().getWidth() ) <= ( figureTouche.getPosX() + figureTouche.getImgFigure().getWidth() ) )
            	)
            	&&
            	(
            		( figures.get(i).getLaser().getPosY() >= figureTouche.getPosY()  && figures.get(i).getLaser().getPosY() <= ( figureTouche.getPosY() + figureTouche.getImgFigure().getHeight() ) ) ||
                	( ( figures.get(i).getLaser().getPosY() + figures.get(i).getLaser().getImgFigure().getHeight() ) >= figureTouche.getPosY()  && ( figures.get(i).getLaser().getPosY() + figures.get(i).getLaser().getImgFigure().getHeight() ) <= ( figureTouche.getPosY() + figureTouche.getImgFigure().getHeight() ) )
            	)
            )
			{
				if(destructLaser)figures.get(i).getLaser().destruct(container);
				return true;
            }
        }
		return false;
	}

}
